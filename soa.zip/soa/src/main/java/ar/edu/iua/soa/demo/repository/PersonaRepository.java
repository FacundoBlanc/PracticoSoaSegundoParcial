package ar.edu.iua.soa.demo.repository;

import ar.edu.iua.soa.demo.model.Persona;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PersonaRepository extends JpaRepository<Persona, Integer> {
    public Persona findByLegajo(String legajo);
}
