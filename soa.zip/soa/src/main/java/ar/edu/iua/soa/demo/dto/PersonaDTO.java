package ar.edu.iua.soa.demo.dto;

public class PersonaDTO {
    // private Integer id_persona;
    private String legajo;

    public PersonaDTO(String legajo) {
        this.legajo = legajo;
    }

    public String getLegajo() {
        return legajo;
    }

    public void setLegajo(String legajo) {
        this.legajo = legajo;
    }

}
