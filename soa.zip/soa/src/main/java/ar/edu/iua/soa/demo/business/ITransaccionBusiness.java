package ar.edu.iua.soa.demo.business;

import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.TransaccionRechazadaException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.model.Transaccion;

import java.util.List;

public interface ITransaccionBusiness {
    public Transaccion addTransaccion (Persona persona) throws InvalidPersonaException, TransaccionRechazadaException;

    public List<Transaccion> getTransaccionesFecha(String fecha);
}
