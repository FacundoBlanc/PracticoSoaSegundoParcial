package ar.edu.iua.soa.demo.business.implementation;

import ar.edu.iua.soa.demo.business.ITransaccionBusiness;
import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.dto.PostPagoDTO;
import ar.edu.iua.soa.demo.dto.TransaccionDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.TransaccionRechazadaException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.model.Transaccion;
import ar.edu.iua.soa.demo.repository.PersonaRepository;
import ar.edu.iua.soa.demo.repository.TransaccionRepository;
import com.google.gson.Gson;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class TransaccionBusiness implements ITransaccionBusiness {

    private String url = "https://iua-service.herokuapp.com/transferir";

    @Autowired
    private TransaccionRepository transaccionDAO;

    @Autowired
    private PersonaRepository personaDAO;

    @Override
    public Transaccion addTransaccion(Persona personaa) throws InvalidPersonaException, TransaccionRechazadaException {
        Persona persona = personaDAO.findByLegajo(personaa.getLegajo());    // CON EL LEGAJO QUE OBTENGO DEL POST, BUSCO En la BDD LA PERSONA POR SU LEGAJO
        Transaccion transaccion = new Transaccion();
        TransaccionDTO txDto = new TransaccionDTO();
        PostPagoDTO postPagoDTO = new PostPagoDTO();
        Date date = new Date();         // Fecha del sistema
        Gson gjson = new Gson();
        String url = "https://iua-service.herokuapp.com/transferir";

        HttpClient client = HttpClientBuilder.create().build();
        HttpPost postRequest = new HttpPost(url);               // Creo un post a la URL

        if(persona == null){  // Quiere decir que no se obtuvo una persona con el legajo indicado
            throw new InvalidPersonaException();
        }

        postPagoDTO.setMonto(persona.getMonto_mensual());       // Al dto Le seteo el monto/sueldo y el cbu que obtuve de la persona
        postPagoDTO.setCbu(persona.getCbu());

        try {
            StringEntity paramss =new StringEntity(gjson.toJson(postPagoDTO));
            postRequest.setHeader("Content-type", "application/json");
            postRequest.setEntity(paramss);
            HttpResponse response = client.execute(postRequest);
            System.out.println("Response Code : " + response.getStatusLine().getStatusCode());  // Response de la api del profe
            BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            while ((line = rd.readLine()) != null) {
                Gson g = new Gson();
                txDto = g.fromJson(line, TransaccionDTO.class);
            }


        } catch (Exception e) {
            System.out.println(e);
        }

        if(txDto.getEstado().equals("ERROR")){  // La api no aprobo la transaccion
            System.out.println(txDto.getEstado());
            throw new TransaccionRechazadaException();
        }

        transaccion.setCodigo_aprobacion(txDto.getCodigo());
        transaccion.setEstado_transaccion(txDto.getEstado());
        transaccion.setFecha_pago(date);
        transaccion.setLegajo(personaa.getLegajo());
        transaccion.setMonto(persona.getMonto_mensual());
        return transaccionDAO.save(transaccion);
    }

    @Override
    public List<Transaccion> getTransaccionesFecha(String fecha){

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date fecha_pago = null;

        System.out.println("entro aca");
        System.out.println("fecha: " + fecha);

        /* try{
            fecha_pago = format.parse(fecha);
        } catch (ParseException ex) {

            ex.printStackTrace();

        }


        return transaccionDAO.findAllByFecha_pago(fecha_pago);*/
        return null;
    }
}
