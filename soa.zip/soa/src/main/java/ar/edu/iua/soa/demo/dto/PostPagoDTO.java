package ar.edu.iua.soa.demo.dto;

public class PostPagoDTO {
    String cbu;
    Integer monto;

    public String getCbu() {
        return cbu;
    }

    public void setCbu(String cbu) {
        this.cbu = cbu;
    }

    public Integer getMonto() {
        return monto;
    }

    public void setMonto(Integer monto) {
        this.monto = monto;
    }
}
