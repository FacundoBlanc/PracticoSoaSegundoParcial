package ar.edu.iua.soa.demo.services;

import ar.edu.iua.soa.demo.business.IPersonaBusiness;
import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.LegajoExistenteException;
import ar.edu.iua.soa.demo.model.Persona;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(Constantes.URL_PERSONA)
public class PersonaRESTController {
    @Autowired
    private IPersonaBusiness iPersonaBusiness;

    final static Logger log = Logger.getLogger("ListaRESTController.class");

    @RequestMapping(value = { "", "/" }, method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<Persona> addPersona(@RequestBody Persona persona){
        try {
            Persona per = iPersonaBusiness.addPersona(persona);
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("location", "/persona/" + per.getId_persona());
            return new ResponseEntity<Persona>(per, responseHeaders, HttpStatus.CREATED);
        }catch (InvalidPersonaException ex){
            log.error("Cbu, monto y legajo no pueden ser null, negativos o estar vacios");
            return new ResponseEntity<Persona>(HttpStatus.NOT_ACCEPTABLE);
        }catch (LegajoExistenteException ex){
            log.error("Ya existe una persona con el legajo: " + persona.getLegajo());
            return new ResponseEntity<Persona>(HttpStatus.NOT_ACCEPTABLE);
        }
    }
}
