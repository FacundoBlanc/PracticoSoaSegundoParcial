package ar.edu.iua.soa.demo.repository;

import ar.edu.iua.soa.demo.model.Transaccion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface TransaccionRepository extends JpaRepository<Transaccion, Integer> {
    // public List<Transaccion> getAllByFecha_pagoContaining(Date fecha_pago);
}
