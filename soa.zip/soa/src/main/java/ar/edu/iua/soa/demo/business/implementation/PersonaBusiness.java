package ar.edu.iua.soa.demo.business.implementation;

import ar.edu.iua.soa.demo.business.IPersonaBusiness;
import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.LegajoExistenteException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.repository.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonaBusiness implements IPersonaBusiness {

    @Autowired
    private PersonaRepository personaDAO;

   public Persona addPersona(Persona persona) throws InvalidPersonaException, LegajoExistenteException {
       Persona per = personaDAO.findByLegajo(persona.getLegajo());
       if(persona.getMonto_mensual() == null || persona.getLegajo() == null || persona.getCbu() == null
          || persona.getMonto_mensual().equals("") || persona.getLegajo().equals("") || persona.getCbu().equals("") || persona.getMonto_mensual() < 0){
           throw new InvalidPersonaException();
       }else if(per != null){  // quiere decir que ya existe una persona con ese legajo
           throw new LegajoExistenteException();
       }else{
           return personaDAO.save(persona);
       }
   }
}
