package ar.edu.iua.soa.demo.services;

import ar.edu.iua.soa.demo.business.ITransaccionBusiness;
import ar.edu.iua.soa.demo.dto.PersonaDTO;
import ar.edu.iua.soa.demo.exceptions.InvalidPersonaException;
import ar.edu.iua.soa.demo.exceptions.NotFoundException;
import ar.edu.iua.soa.demo.exceptions.TransaccionRechazadaException;
import ar.edu.iua.soa.demo.model.Persona;
import ar.edu.iua.soa.demo.model.Transaccion;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constantes.URL_TRANSACCION)
public class TransaccionRESTController {

    @Autowired
    private ITransaccionBusiness transaccionBusiness;

    final static Logger log = Logger.getLogger("ListaRESTController.class");

    @RequestMapping(value = { "", "/" }, method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<Transaccion> addTransaccion(@RequestBody Persona persona){
        try{
            Transaccion tx = transaccionBusiness.addTransaccion(persona);
            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.set("location", "/transaccion/" + tx.getId_transaccion());
            return new ResponseEntity<Transaccion>(tx, responseHeaders, HttpStatus.CREATED);
        }catch (InvalidPersonaException ex){
            log.error("No existe una persona con el legajo: " + persona.getLegajo());
            return new ResponseEntity<Transaccion>(HttpStatus.NOT_ACCEPTABLE);
        }catch (TransaccionRechazadaException ex){
            log.error("No se ha aprobado la transaccion");
            return new ResponseEntity<Transaccion>(HttpStatus.NOT_ACCEPTABLE);
        }
    }

    @RequestMapping(value = { "/{fecha}" }, method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<Transaccion>> getTransaccionesPorFecha(@PathVariable("fecha") String fecha) {
            log.debug("entro acaaaaa");
            return new ResponseEntity<List<Transaccion>>(transaccionBusiness.getTransaccionesFecha(fecha), HttpStatus.OK);
    }
}
