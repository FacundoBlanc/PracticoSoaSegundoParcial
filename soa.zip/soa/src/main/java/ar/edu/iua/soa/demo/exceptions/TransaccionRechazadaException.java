package ar.edu.iua.soa.demo.exceptions;

public class TransaccionRechazadaException extends Exception {
    private static final long serialVersionUID = -5086907350023253630L;

    public TransaccionRechazadaException() {
    }

    public TransaccionRechazadaException(String message) {
        super(message);
    }

    public TransaccionRechazadaException(Throwable cause) {
        super(cause);
    }

    public TransaccionRechazadaException(String message, Throwable cause) {
        super(message, cause);
    }

    public TransaccionRechazadaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);

    }
}
